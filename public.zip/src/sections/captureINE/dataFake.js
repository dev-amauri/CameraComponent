export const ineMockData = {
    estatus: true,
    nombres: "Juan Carlos",
    primerApellido: "Pérez",
    segundoApellido: "Hernández",
    curp: "PEHJ890123HDFLRN01",
    fechaNacimiento: "1989-01-23",
    direccion: {
      calle: "Av. Revolución",
      cruzamiento1: "Calle Libertad",
      cruzamiento2: "Calle Independencia",
      numeroExterior: "123",
      numeroInterior: "4B",
      codigoPostal: "76000",
      estado: "Querétaro",
      municipio: "Querétaro",
      colonia: "Centro Histórico"
    }
  };
  