export default function HelpPage() {
  return <h1>Help Page</h1>;
}