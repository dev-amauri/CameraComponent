import CameraINE from "@/sections/captureINE/CameraINE";
import { FormDataINE } from "@/sections/captureINE/FormDataINE";


export default function INEDataPage() {
  return (
    <div >
      <FormDataINE/>
      {/* <CameraINE /> */}
    </div>

  );
}